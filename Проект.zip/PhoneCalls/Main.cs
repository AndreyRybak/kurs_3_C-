﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PhoneCalls
{
    internal class Main
    {
        public static void MainMenu()
        {
            Console.Clear();
            Console.WriteLine("                                         =====================================\n" +
                              "                                         |         1.Абоненты                |\n" +
                              "                                         =====================================\n" +
                              "                                         |         2.Города                  |\n" +
                              "                                         =====================================\n" +
                              "                                         |         3.Переговоры              |\n" +
                              "                                         =====================================\n" +
                              "                                         |         4.Выход из программы      |\n" +
                              "                                         =====================================");
            Console.WriteLine("Введите код операции: ");
            char Code = Console.ReadKey(true).KeyChar;
            switch (Code)
            {
                case '1':
                    SubscriberInterface.SubscriberMenu();
                    break;
                case '2':
                    CityInterface.CityMenu();
                    break;
                case '3':
                    CallInterface.CallMenu();
                    break;
                case '4':
                    Environment.Exit(0);
                    break;
                default:
                    Console.WriteLine("Вы ввели неверный код, повторите ввод");
                    Thread.Sleep(1000);
                    MainMenu();
                    break;
            }
        }
    }
}
