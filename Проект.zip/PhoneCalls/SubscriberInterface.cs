﻿using Classes;

namespace PhoneCalls
{
    internal class SubscriberInterface
    {
        public static void SubscriberMenu()
        {
            ICollection<Subscriber> subscribers = new List<Subscriber>();
            int Subscriber_id = -1;

            Subscriber.Initialize(ref subscribers, ref Subscriber_id);
            Console.Clear();
            Console.WriteLine("                                         =====================================\n" +
                              "                                         |     1. Показать абонентов         |\n" +
                              "                                         =====================================\n" +
                              "                                         |     2. Добавить абонента          |\n" +
                              "                                         =====================================\n" +
                              "                                         |     3. Удалить абонента           |\n" +
                              "                                         =====================================\n" +
                              "                                         |     4. Выход в главное меню       |\n" +
                              "                                         =====================================");
            Console.WriteLine("Введите код операции: ");
            char Code = Console.ReadKey(true).KeyChar;
            switch (Code)
            {
                case '1':
                    Showsubscribers(subscribers);
                    break;
                case '2':
                    AddSubscriber(subscribers, Subscriber_id);
                    break;
                case '3':
                    DeleteSubscriber(subscribers);
                    break;
                case '4':
                    Main.MainMenu();
                    break;
                default:
                    Console.WriteLine("Вы ввели неверный код, повторите ввод");
                    Thread.Sleep(1000);
                    SubscriberMenu();
                    break;
            }
        }

        internal static void Showsubscribers(ICollection<Subscriber> subscribers)
        {
            Console.Clear();
            if (subscribers.Count() == 0)
            {
                Console.WriteLine("Абонентов нет");
                Console.WriteLine("Нажмите любую кнопку чтобы вернуться в меню...");
            }
            else
            {
                foreach (Subscriber Subscriber in subscribers)
                {
                    Subscriber.Show();
                }
            }
            Console.ReadKey();
            SubscriberMenu();
        }

        static void AddSubscriber(ICollection<Subscriber> subscribers, int Subscriber_id)
        {
            Console.Clear();
            try
            {
                Console.WriteLine("Введите номер телефона");
                string PhoneNumber = Console.ReadLine();
                Console.WriteLine("Введите ИНН");
                string INN = Console.ReadLine();
                Console.WriteLine("Введите адрес");
                string Adres = Console.ReadLine();
                Subscriber_id++;
                Subscriber Subscriber = new Subscriber(Subscriber_id, PhoneNumber,INN,Adres);
                subscribers.Add(Subscriber);
                Subscriber.Write(subscribers);
                SubscriberMenu();
            }
            catch
            {
                Console.WriteLine("Вы ввели неверные данные, повторите ввод. Нажмите любую кнопку чтобы продолжить");
                Console.ReadKey();
                AddSubscriber(subscribers, Subscriber_id);
            }
        }

        static void DeleteSubscriber(ICollection<Subscriber> subscribers)
        {
            Console.Clear();
            if (subscribers.Count != 0)
            {
                foreach (Subscriber Subscriber in subscribers)
                {
                    Subscriber.Show();
                }
                Console.WriteLine("Введите код нужного абонента");
                try
                {
                    int id = int.Parse(Console.ReadLine());
                    var temp = subscribers.Where(d => d.Id == id).First();
                    subscribers.Remove(temp);
                    Subscriber.Write(subscribers);
                }
                catch
                {
                    Console.WriteLine("Абонента с таким кодом не существует");
                    Console.WriteLine("Нажмите любую кнопку чтобы вернуться в меню...");
                    Console.ReadKey();
                    SubscriberMenu();
                }
            }
            else
            {
                Console.WriteLine("Нет абонентов для удаления");
                Console.WriteLine("Нажмите любую кнопку чтобы вернуться в меню...");
                Console.ReadKey();
            }
            SubscriberMenu();
        }
    }
}
