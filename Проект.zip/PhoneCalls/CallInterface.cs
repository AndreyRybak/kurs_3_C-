﻿using Classes;

namespace PhoneCalls
{
    internal class CallInterface
    {
        public static void CallMenu()
        {
            ICollection<Call> calls = new List<Call>();
            int Call_id = -1;
            Call.Initialize(ref calls, ref Call_id);
            Console.Clear();
            Console.WriteLine("                                         =====================================\n" +
                              "                                         |        1. Показать переговоры     |\n" +
                              "                                         =====================================\n" +
                              "                                         |        2. Добавить переговоры     |\n" +
                              "                                         =====================================\n" +
                              "                                         |        3. Удалить переговоры      |\n" +
                              "                                         =====================================\n" +
                              "                                         |        4. Выход в главное меню    |\n" +
                              "                                         =====================================");
            Console.WriteLine("Введите код операции: ");
            char Code = Console.ReadKey(true).KeyChar;
            switch (Code)
            {
                case '1':
                    Showcalls(calls);
                    break;
                case '2':
                    AddCall(calls, Call_id);
                    break;
                case '3':
                    DeleteCall(calls);
                    break;
                case '4':
                    Main.MainMenu();
                    break;
                default:
                    Console.WriteLine("Вы ввели неверный код, повторите ввод");
                    Thread.Sleep(1000);
                    CallMenu();
                    break;
            }
        }

        internal static void Showcalls(ICollection<Call> calls)
        {
            Console.Clear();
            if (calls.Count == 0)
            {
                Console.WriteLine("Переговоров нет");
            }
            else
            {
                foreach (Call Call in calls)
                {
                    Call.Show();
                }
            }
            Console.WriteLine("Нажмите любую кнопку чтобы вернуться в меню...");
            Console.ReadKey();
            CallMenu();
        }

        internal static void AddCall(ICollection<Call> calls, int Call_id)
        {
            ICollection<Subscriber> subscribers = new List<Subscriber>();
            int Subscriber_id = -1;
            Subscriber.Initialize(ref subscribers, ref Subscriber_id);
            ICollection<City> cities = new List<City>();
            int City_id = -1;
            City.Initialize(ref cities, ref City_id);
            Console.Clear();
            if (subscribers.Count == 0)
            {
                Console.WriteLine("Нет абонентов для переговоров");
                Console.WriteLine("Нажмите любую кнопку чтобы вернуться в меню...");
                Console.ReadKey();
                CallMenu();
            }
            else
            {
                foreach (Subscriber Subscriber in subscribers)
                {
                    Subscriber.Show();
                }
                try
                {
                    Console.WriteLine("Введите код абонента");
                    int Code1 = int.Parse(Console.ReadLine());
                    int temp1 = subscribers.Where(d => d.Id == Code1).First().Id;
                    Console.Clear();
                    if (cities.Count == 0)
                    {
                        Console.WriteLine("Нет городов для переговоров");
                        Console.WriteLine("Нажмите любую кнопку чтобы вернуться в меню...");
                        Console.ReadKey();
                        CallMenu();
                    }
                    else
                    {
                        foreach (City City in cities)
                        {
                            City.Show();
                        }
                        Console.WriteLine("Введите код города");
                        int Code2 = int.Parse(Console.ReadLine());
                        int temp2 = cities.Where(d => d.Id == Code2).First().Id;
                        Console.Clear();
                        Console.WriteLine("Введите дату");
                        DateOnly Date = DateOnly.Parse(Console.ReadLine());
                        int Minutes = int.Parse(Console.ReadLine());
                        Console.WriteLine("Если время суток дневное напишите True, если ночное напишите False");
                        bool DayOrNight =bool.Parse(Console.ReadLine());
                        Call_id++;
                        Call Call = new Call(Call_id, temp1, temp2, Date, Minutes, DayOrNight);
                        calls.Add(Call);
                        Call.Write(calls);
                    }
                }
                catch
                {
                    Console.WriteLine("Вы ввели неверные данные, повторите ввод. Нажмите любую кнопку для продолжения");
                    Console.ReadKey();
                    CallMenu();
                }
            }
            CallMenu();
        }

        internal static void DeleteCall(ICollection<Call> calls)
        {
            Console.Clear();
            if (calls.Count == 0)
            {
                ;
                Console.WriteLine("Нет переговоров для удаления");
                Console.WriteLine("Нажмите любую кнопку чтобы вернуться в меню...");
                Console.ReadKey();
            }
            else
            {
                Console.WriteLine("Введите код переговора, который вы ходите удалить");
                int id = int.Parse(Console.ReadLine());
                var temp = calls.Where(d => d.Id == id).First();
                if (temp != null)
                {
                    calls.Remove(temp);
                    Call.Write(calls);
                }
                else
                {
                    Console.WriteLine("Переговора с таким кодом не существует");
                    Console.WriteLine("Нажмите любую кнопку чтобы вернуться в меню...");
                    Console.ReadKey();
                }
            }
            CallMenu();
        }
    }
}
