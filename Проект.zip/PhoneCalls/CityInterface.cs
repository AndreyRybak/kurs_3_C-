﻿using Classes;
using System.Runtime.InteropServices;

namespace PhoneCalls
{
    internal class CityInterface
    {
        public static void CityMenu()
        {
            ICollection<City> cities = new List<City>();
            int City_id = -1;

            City.Initialize(ref cities, ref City_id);
            Console.Clear();
            Console.WriteLine("                                         =====================================\n" +
                              "                                         |     1. Показать города            |\n" +
                              "                                         =====================================\n" +
                              "                                         |     2. Добавить город             |\n" +
                              "                                         =====================================\n" +
                              "                                         |     3. Удалить город              |\n" +
                              "                                         =====================================\n" +
                              "                                         |     4. Выход в главное меню       |\n" +
                              "                                         =====================================");
            Console.WriteLine("Введите код операции: ");
            char Code = Console.ReadKey(true).KeyChar;
            switch (Code)
            {
                case '1':
                    Showcities(cities);
                    break;
                case '2':
                    AddCity(cities, City_id);
                    break;
                case '3':
                    DeleteCity(cities);
                    break;
                case '4':
                    Main.MainMenu();
                    break;
                default:
                    Console.WriteLine("Вы ввели неверный код, повторите ввод");
                    Thread.Sleep(1000);
                    CityMenu();
                    break;
            }
        }

        internal static void Showcities(ICollection<City> cities)
        {
            Console.Clear();
            if (cities.Count() == 0)
            {
                Console.WriteLine("Городов нет");
                Console.WriteLine("Нажмите любую кнопку чтобы вернуться в меню...");
            }
            else
            {
                foreach (City City in cities)
                {
                    City.Show();
                }
            }
            Console.ReadKey();
            CityMenu();
        }

        static void AddCity(ICollection<City> cities, int City_id)
        {
            Console.Clear();
            try
            {
                Console.WriteLine("Введите название города");
                string Name = Console.ReadLine();
                Console.WriteLine("Введите дневной тариф");
                int DayPay = int.Parse(Console.ReadLine());
                Console.WriteLine("Введите ночной тариф");
                int NightPay = int.Parse(Console.ReadLine());
                City_id++;
                City City = new City(City_id,Name,DayPay,NightPay);
                cities.Add(City);
                City.Write(cities);
                CityMenu();
            }
            catch
            {
                Console.WriteLine("Вы ввели неверные данные, повторите ввод. Нажмите любую кнопку чтобы продолжить");
                Console.ReadKey();
                AddCity(cities, City_id);
            }
        }

        static void DeleteCity(ICollection<City> cities)
        {
            Console.Clear();
            if (cities.Count != 0)
            {
                foreach (City City in cities)
                {
                    City.Show();
                }
                Console.WriteLine("Введите код нужного города");
                try
                {
                    int id = int.Parse(Console.ReadLine());
                    var temp = cities.Where(d => d.Id == id).First();
                    cities.Remove(temp);
                    City.Write(cities);
                }
                catch
                {
                    Console.WriteLine("Города с таким кодом не существует");
                    Console.WriteLine("Нажмите любую кнопку чтобы вернуться в меню...");
                    Console.ReadKey();
                    CityMenu();
                }
            }
            else
            {
                Console.WriteLine("Нет города для удаления");
                Console.WriteLine("Нажмите любую кнопку чтобы вернуться в меню...");
                Console.ReadKey();
            }
            CityMenu();
        }
    }
}
