﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Classes
{
    public class Call
    {
        const string path = "calls.txt";
        public int Id { get; set; }
        int SubscriberId { get; set; }
        int CityId { get; set; }
        DateOnly Date { get; set; }
        int Minutes { get; set; }
        bool DayOrNight { get; set; }
        public Call(int id, int subscriberId, int cityId, DateOnly date, int minutes, bool dayOrNight)
        {
            Id = id;
            SubscriberId = subscriberId;
            CityId = cityId;
            Date = date;
            Minutes = minutes;
            DayOrNight = dayOrNight;
        }
        public void Show()
        {
            Console.WriteLine("==================================================\n" +
                              $"Код переговора {Id}\n" +
                              $"Код абонента {SubscriberId}\n" +
                              $"Код города {CityId}\n" +
                              $"Дата {Date}\n" +
                              $"Количество минут {Minutes}\n");
            if ( DayOrNight )
            {
                Console.WriteLine("Время суток день");
            }
            else
            {
                Console.WriteLine("Время суток ночь");
            }
        }
        string ToString()
        {
            return $"{Id},{SubscriberId},{CityId},{Date},{Minutes},{DayOrNight}";
        }
        static Call ToClass(string line)
        {
            string[] mas = line.Split(',');
            Call call = new Call(int.Parse(mas[0]), int.Parse(mas[1]), int.Parse(mas[2]), DateOnly.Parse(mas[3]), int.Parse(mas[4]), bool.Parse(mas[5]));
            return call;
        }
        public static void Initialize(ref ICollection<Call> calls, ref int call_id)
        {
            if (File.Exists(path))
            {
                using (StreamReader reader = new(path))
                {
                    while (!reader.EndOfStream)
                    {
                        calls.Add(ToClass(reader.ReadLine()));
                    }
                }
                if (calls.Count > 0) { call_id = calls.Last().Id; }
            }
        }
        public static void Write(ICollection<Call> calls)
        {
            using (StreamWriter writer = new(path, false))
            {
                foreach (Call call in calls)
                {
                    writer.WriteLine(call.ToString());
                }
            }
        }
    }
}
