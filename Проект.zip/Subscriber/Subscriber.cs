﻿namespace Classes
{
    public class Subscriber
    {
        const string path = "subscribers.txt";
        public int Id { get; set; }
        string Phone { get; set; }
        string INN { get; set; }
        string Adres { get; set; }
        public Subscriber(int id, string phone, string iNN, string adres)
        {
            Id = id;
            Phone = phone;
            INN = iNN;
            Adres = adres;
        }
        public void Show()
        {
            Console.WriteLine("==============================================\n" +
                              $"Код абонента {Id}\n" +
                              $"Номер телефона {Phone}\n" +
                              $"ИНН {INN}\n" +
                              $"Адрес {Adres}\n" +
                              "==============================================\n");
        }
        string ToString()
        {
            return $"{Id},{Phone},{INN},{Adres}";
        }
        static Subscriber ToClass(string line)
        {
            string[] mas = line.Split(',');
            Subscriber subsriber = new Subscriber(int.Parse(mas[0]), mas[1], mas[2], mas[3]);
            return subsriber;
        }
        public static void Initialize(ref ICollection<Subscriber> subscribers, ref int subscriber_id)
        {
            if (File.Exists(path))
            {
                using (StreamReader reader = new(path))
                {
                    while (!reader.EndOfStream)
                    {
                        subscribers.Add(ToClass(reader.ReadLine()));
                    }
                }
                if (subscribers.Count > 0) { subscriber_id = subscribers.Last().Id; }
            }
        }
        public static void Write(ICollection<Subscriber> subscribers)
        {
            using (StreamWriter writer = new(path, false))
            {
                foreach (Subscriber subsriber in subscribers)
                {
                    writer.WriteLine(subsriber.ToString());
                }
            }
        }
    }
}