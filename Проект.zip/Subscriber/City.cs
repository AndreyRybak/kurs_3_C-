﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Classes
{
    public class City
    {
        const string path = "cities.txt";

        public int Id { get; set; }
        string Name { get; set; }
        decimal DayPay { get; set; }
        decimal NightPay { get; set; }
        public City(int id, string name, decimal dayPay, decimal nightPay)
        {
            Id = id;
            Name = name;
            DayPay = dayPay;
            NightPay = nightPay;
        }
        public void Show()
        {
            Console.WriteLine("==============================================\n" +
                              $"Код города {Id}\n" +
                              $"Название {Name}\n" +
                              $"Дневной тариф {DayPay}\n" +
                              $"Ночной тариф {NightPay}\n" +
                              "==============================================\n");
        }
        string ToString()
        {
            return $"{Id},{Name},{DayPay},{NightPay}";
        }
        static City ToClass(string line)
        {
            string[] mas = line.Split(',');
            City city = new City(int.Parse(mas[0]), mas[1], decimal.Parse(mas[2]), decimal.Parse(mas[3]));
            return city;
        }
        public static void Initialize(ref ICollection<City> cities, ref int city_id)
        {
            if (File.Exists(path))
            {
                using (StreamReader reader = new(path))
                {
                    while (!reader.EndOfStream)
                    {
                        cities.Add(ToClass(reader.ReadLine()));
                    }
                }
                if (cities.Count > 0) { city_id = cities.Last().Id; }
            }
        }
        public static void Write(ICollection<City> cities)
        {
            using (StreamWriter writer = new(path, false))
            {
                foreach (City city in cities)
                {
                    writer.WriteLine(city.ToString());
                }
            }
        }
    }
}
